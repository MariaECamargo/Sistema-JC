<?php
session_start();

// Verificar se o usuário está autenticado
if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    // Redirecionar para a tela de login se não estiver autenticado
    header('Location: login.php');
    exit;
}

// Conectar ao banco de dados 
$servername = "localhost";
$username = "root";
$password = "";
$database = "sistema_jc";

$conn = new mysqli($servername, $username, $password, $database);

// Verificar a conexão
if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}

$sql = "SELECT id, nome_nota, arquivo_pdf FROM notas_fiscais";
$result = $conn->query($sql);

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Sistema JC - Listagem de Notas Fiscais</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #001f3f;
            color: #fff;
        }
        .header-container {
            display: flex;
            align-items: center;
            padding: 10px;
            background-color: #028ac4; 
            border-bottom: 1px solid #fff; 
            margin-bottom: 20px;
        }
        .header-container img {
            max-height: 50px; 
        }
        .content-container {
            max-width: 800px;
            margin: auto;
        }
        .table-container {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="header-container">
    <img src="img/Asset-11.png" alt="Logo da JC Instalações Elétricas">
    <div class="company-name">JC Instalações Elétricas</div>
</div>

<div class="container content-container">
    <h2 class="text-center mb-4">Listagem de Notas Fiscais</h2>

    <div class="table-container">
        <?php
        if ($result->num_rows > 0) {
            echo '<table class="table table-bordered table-dark">';
            echo '<thead>';
            echo '<tr>';
            echo '<th scope="col">ID</th>';
            echo '<th scope="col">Nome da Nota</th>';
            echo '<th scope="col">Ações</th>';
            echo '</tr>';
            echo '</thead>';
            echo '<tbody>';

            while ($row = $result->fetch_assoc()) {
                echo '<tr>';
                echo '<td>' . $row['id'] . '</td>';
                echo '<td>' . $row['nome_nota'] . '</td>';
                echo '<td><a href="visualizarNota.php?id=' . $row['id'] . '">Visualizar</a></td>';
                echo '</tr>';
            }

            echo '</tbody>';
            echo '</table>';
        } else {
            echo 'Nenhuma nota fiscal encontrada.';
        }
        ?>
    </div>
    <a href="cadastroNotaFiscal.php" class="btn btn-secondary btn-block menu-btn">Retornar</a>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
