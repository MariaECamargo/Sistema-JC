<?php
session_start();

// Verificar se o usuário está autenticado
if($_SERVER["REQUEST_METHOD"] == "POST") {
    // Conectar ao banco de dados 
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "sistema_jc";

    $conn = new mysqli($servername, $username, $password, $database);

    // Verificar a conexão
    if ($conn->connect_error) {
        die("Erro na conexão com o banco de dados: " . $conn->connect_error);
    }

    // Capturar dados do formulário
    $nomeItem = $_POST["nome_item"];
    $descricao = $_POST["descricao"];
    $quantidade = $_POST["quantidade"];
    $valorItem = $_POST["valor_item"];

    // Inserir dados no banco de dados usando prepared statement
    $sql = "INSERT INTO estoque (nome_item, descricao, quantidade, valor_item) VALUES (?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssdd", $nomeItem, $descricao, $quantidade, $valorItem);
    
    if ($stmt->execute()) {
        echo "Item inserido com sucesso!";
    } else {
        echo "Erro na inserção do item: " . $stmt->error;
    }


    // Fechar a conexão com o banco de dados
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Sistema JC - Inclusão de Estoque</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #001f3f; 
            color: #fff;
        }
        .header-container {
            display: flex;
            align-items: center;
            padding: 10px;
            background-color: #028ac4;
            border-bottom: 1px solid #fff; 
            margin-bottom: 20px;
        }
        .header-container img {
            max-height: 50px; 
        }
        .menu-container {
            max-width: 600px;
            margin: auto;
            margin-top: 20px;
        }
        .form-container {
            max-width: 400px;
            margin: auto;
        }
        .form-group {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<div class="header-container">
    <img src="img/Asset-11.png" alt="Logo da JC Instalações Elétricas">
    <div class="company-name">JC Instalações Elétricas</div>
</div>

<div class="container form-container">
    <h2 class="text-center mb-4">Inclusão de Estoque</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <div class="form-group">
            <label for="nome_item">Nome no Item:</label>
            <input type="text" class="form-control" id="nome_item" name="nome_item" required>
        </div>
        <div class="form-group">
            <label for="descricao">Descrição:</label>
            <input type="text" class="form-control" id="descricao" name="descricao" required>
        </div>
        <div class="form-group">
            <label for="quantidade">Quantidade:</label>
            <input type="number" class="form-control" id="quantidade" name="quantidade" required>
        </div>
        <div class="form-group">
            <label for="valor_item">Valor do Item:</label>
            <input type="text" class="form-control" id="valor_item" name="valor_item" step="0,01" required>
        </div>
        <button type="submit" class="btn btn-primary btn-block">Inserir Item</button>
        <a href="estoque.php" class="btn btn-secondary btn-block menu-btn">Retornar</a>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
