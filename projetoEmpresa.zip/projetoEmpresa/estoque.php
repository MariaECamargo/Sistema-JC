<?php
session_start();

// Verificar se o usuário está autenticado
if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    // Redirecionar para a tela de login se não estiver autenticado
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Sistema JC - Estoque</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #001f3f; 
            color: #fff;
        }
        .header-container {
            display: flex;
            align-items: center;
            padding: 10px;
            background-color: #028ac4; 
            border-bottom: 1px solid #fff; 
            margin-bottom: 20px;
        }
        .header-container img {
            max-height: 50px; 
        }
        .menu-container {
            max-width: 600px;
            margin: auto;
            margin-top: 20px;
        }
        .menu-btn {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

<div class="header-container">
    <img src="img/Asset-11.png" alt="Logo da JC Instalações Elétricas">
    <div class="company-name"><strong>JC Instalações Elétricas</strong></div>
</div>

<div class="container menu-container">
    <h2 class="text-center mb-4">Estoque</h2>
    
    <a href="inclusaoEstoque.php" class="btn btn-primary btn-block menu-btn">Inclusão de Estoque</a>
    <a href="listagemEstoque.php" class="btn btn-primary btn-block menu-btn">Listagem de Estoque</a>
    <a href="baixaEstoque.php" class="btn btn-primary btn-block menu-btn">Baixa de Estoque</a>
    <a href="contabilizacao.php" class="btn btn-primary btn-block menu-btn">Contabilização de Estoque</a>
    <a href="principal.php" class="btn btn-secondary btn-block menu-btn">Retornar</a>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
