<?php
session_start();

// Verificar se o usuário está autenticado
if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    header('Location: login.php');
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$database = "sistema_jc";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}

// Verificar se o ID do orçamento foi passado pela URL
if (isset($_GET['id'])) {
    $idOrcamento = $_GET['id'];

    // Consulta SQL para obter os detalhes do orçamento com base no ID
    $sql = "SELECT * FROM orcamentos WHERE id = $idOrcamento";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Sistema JC - Detalhes do Orçamento</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #001f3f;
            color: #fff;
        }
        .header-container {
            display: flex;
            align-items: center;
            padding: 10px;
            background-color: #028ac4;
            border-bottom: 1px solid #fff; 
            margin-bottom: 20px;
        }
        .header-container img {
            max-height: 50px;
        }
        .details-container {
            max-width: 600px;
            margin: auto;
            margin-top: 20px;
        }
        .details-container h2 {
            color: #fff;
        }
        .details-container p {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

<div class="header-container">
    <img src="img/Asset-11.png" alt="Logo da JC Instalações Elétricas">
    <div class="company-name">JC Instalações Elétricas</div>
</div>

<div class="container details-container">
    <h2>Detalhes do Orçamento</h2>

    <p><strong>Nome do Cliente:</strong> <?php echo $row['nome_cliente']; ?></p>
    <p><strong>Telefone do Cliente:</strong> <?php echo $row['telefone_cliente']; ?></p>
    <p><strong>Local do Serviço:</strong> <?php echo $row['local_servico']; ?></p>
    <p><strong>Tipo de serviço:</strong> <?php echo $row['tipo_servico']; ?></p>
    <p><strong>Materiais a serem utilizados:</strong> <?php echo $row['materiais_utilizados']; ?></p>
    <p><strong>Valor do Orçamento:</strong> <?php echo $row['valor_orcamento']; ?></p>
    <p><strong>Valor da mão de obra:</strong> <?php echo $row['valor_mao_obra']; ?></p>
    <p><strong>Data do Cadastro:</strong> <?php echo $row['data_cadastro']; ?></p>
    <p><strong>Observações:</strong> <?php echo $row['observacoes']; ?></p>
    <a href="orcamentoExistente.php" class="btn btn-secondary">Voltar para Orçamentos</a>
</div>


<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>

<?php
    } else {
        echo "<p>Orçamento não encontrado.</p>";
    }
} else {
    echo "<p>ID do orçamento não fornecido.</p>";
}

$conn->close();
?>
