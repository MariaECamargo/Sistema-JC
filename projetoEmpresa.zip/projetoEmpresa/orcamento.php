<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Sistema JC - Orçamento</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>

        body {
            background-color: #001f3f; 
            color: #fff;
        }
        .header-container {
            display: flex;
            align-items: center;
            padding: 10px;
            background-color: #028ac4; 
            border-bottom: 1px solid #fff; 
            margin-bottom: 20px;
        }
        .header-container img {
            max-height: 50px; 
        }
        .content-container {
            max-width: 800px;
            margin: auto;
            text-align: center; 
        }
        .btn-container {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .btn-container .btn {
            width: 100%;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

<div class="header-container">
    <img src="img/Asset-11.png" alt="Logo da JC Instalações Elétricas">
    <div class="company-name">JC Instalações Elétricas</div>
</div>

<div class="container content-container">
    <h2 class="text-center mb-4">Orçamento</h2>

    <div class="btn-container">
        <a href="novoOrcamento.php" class="btn btn-primary btn-block">Novo Orçamento</a>
        <a href="orcamentoExistente.php" class="btn btn-primary btn-block">Orçamentos Existentes</a>
        <a href="principal.php" class="btn btn-secondary btn-block menu-btn">Retornar</a>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
