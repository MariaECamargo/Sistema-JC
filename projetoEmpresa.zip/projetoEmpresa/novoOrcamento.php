<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "sistema_jc";

$conn = new mysqli($servername, $username, $password, $database);

// Verificar a conexão
if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}

// Inicializar variáveis
$nome_cliente = $telefone_cliente = $local_servico = $tipo_servico = $materiais_utilizados = $valor_mao_obra = $valor_orcamento = $data_prevista = $observacoes = "";

// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capturar dados do formulário
    $nome_cliente = $_POST["nome_cliente"];
    $telefone_cliente = $_POST["telefone_cliente"];
    $local_servico = $_POST["local_servico"];
    $tipo_servico = $_POST["tipo_servico"];
    $materiais_utilizados = $_POST["materiais_utilizados"];
    $valor_mao_obra = $_POST["valor_mao_obra"];
    $valor_orcamento = $_POST["valor_orcamento"];
    $data_prevista = $_POST["data_prevista"];
    $observacoes = $_POST["observacoes"];


    // Inserir no banco de dados
    $query_inserir = "INSERT INTO orcamentos (nome_cliente, telefone_cliente, local_servico, tipo_servico, materiais_utilizados, valor_mao_obra, valor_orcamento, data_prevista, observacoes) 
                      VALUES ('$nome_cliente', '$telefone_cliente', '$local_servico', '$tipo_servico', '$materiais_utilizados', '$valor_mao_obra', '$valor_orcamento', '$data_prevista', '$observacoes')";

    if ($conn->query($query_inserir) === TRUE) {
        echo "Novo orçamento cadastrado com sucesso!";
    } else {
        echo "Erro ao cadastrar novo orçamento: " . $conn->error;
    }
}

// Fechar a conexão com o banco de dados
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Sistema JC - Novo Orçamento</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <style>
        body {
            background-color: #001f3f;
            color: #fff;
        }
        .header-container {
            display: flex;
            align-items: center;
            padding: 10px;
            background-color: #028ac4;
            border-bottom: 1px solid #fff; 
            margin-bottom: 20px;
        }
        .header-container img {
            max-height: 50px; 
        }
        .content-container {
            max-width: 800px;
            margin: auto;
            text-align: center; 
        }
        .form-container {
            margin-top: 20px;
        }
        .form-group {
            margin-bottom: 15px;
            display: flex;
            align-items: center;
        }
        .form-group label {
            flex: 0 0 150px; 
            margin-bottom: 0; 
        }
        .form-group .form-control {
            flex: 1; 
        }
        .form-group.inline {
            flex-wrap: wrap; 
        }
        .form-group.inline .form-control {
            flex: 0 0 calc(48% - 10px); 
            margin-right: 10px; 
        }
        .form-group.inline .form-control:last-child {
            margin-right: 0; 
        }
        .return{
            height: 50%;
        }
    </style>
</head>
<body>

<div class="header-container">
    <img src="img/Asset-11.png" alt="Logo da JC Instalações Elétricas">
    <div class="company-name">JC Instalações Elétricas</div>
</div>

<div class="container content-container">
    <h2 class="text-center mb-4">Novo Orçamento</h2>

    <div class="form-container">
        <form action="novoOrcamento.php" method="post">
            <div class="form-group">
                <label for="nome_cliente">Nome do Cliente:</label>
                <input type="text" class="form-control" id="nome_cliente" name="nome_cliente" required>
            </div>
            <div class="form-group">
                <label for="telefone_cliente">Telefone do Cliente:</label>
                <input type="text" class="form-control" id="telefone_cliente" name="telefone_cliente" required>
            </div>
            <div class="form-group">
                <label for="local_servico">Local do Serviço:</label>
                <input type="text" class="form-control" id="local_servico" name="local_servico" required>
            </div>
            <div class="form-group">
                <label for="tipo_servico">Tipo de Serviço:</label>
                <input type="text" class="form-control" id="tipo_servico" name="tipo_servico" required>
            </div>
            <div class="form-group">
                <label for="materiais_utilizados">Materiais Utilizados:</label>
                <input type="text" class="form-control" id="materiais_utilizados" name="materiais_utilizados" required>
            </div>
            <div class="form-group">
                <label for="valor_mao_obra">Valor da Mão de Obra:</label>
                <input type="number" step="0.01" class="form-control" id="valor_mao_obra" name="valor_mao_obra" required>
            </div>
            <div class="form-group">
                <label for="valor_orcamento">Valor do Orçamento:</label>
                <input type="number" step="0.01" class="form-control" id="valor_orcamento" name="valor_orcamento" required>
            </div>
            <div class="form-group">
                <label for="data_prevista">Data Prevista para Realização do Serviço:</label>
                <input type="date" class="form-control" id="data_prevista" name="data_prevista" required>
            </div>
            <div class="form-group">
                <label for="observacoes">Observações:</label>
                <textarea class="form-control" id="observacoes" name="observacoes"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Cadastrar Orçamento</button>
            <button type="button" class="btn btn-success" onclick="window.print()">Imprimir Orçamento</button>
            <a href="orcamento.php" class="btn btn-secondary">Voltar para Orçamentos</a>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
