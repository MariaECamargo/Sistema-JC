<?php
// Conectar ao banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$database = "sistema_jc";

$conn = new mysqli($servername, $username, $password, $database);

// Verificar a conexão
if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}

// Verificar se o ID da nota fiscal foi passado na URL
if (isset($_GET['id'])) {
    $id_nota = $_GET['id'];

    // Consultar o banco de dados para obter o caminho do arquivo PDF
    $sql = "SELECT arquivo_pdf FROM notas_fiscais WHERE id = $id_nota";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $arquivo_pdf = $row['arquivo_pdf'];

        // Exibir o PDF
        header("Content-type: application/pdf");
        readfile($arquivo_pdf);
        exit;
    } else {
        echo "Nota fiscal não encontrada.";
    }
} else {
    echo "ID da nota fiscal não fornecido na URL.";
}

// Fechar a conexão com o banco de dados
$conn->close();
?>
