<?php
// Conectar ao banco de dados 
$servername = "localhost";
$username = "root";
$password = "";
$database = "sistema_jc";

$conn = new mysqli($servername, $username, $password, $database);

// Verificar a conexão
if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}

// Inicializar variáveis
$nome_cliente = $rua = $numero = $bairro = $cep = $cidade = $estado = $telefone = "";
$msg = "";

// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capturar dados do formulário
    $nome_cliente = $_POST["nome_cliente"];
    $rua = $_POST["rua"];
    $numero = $_POST["numero"];
    $bairro = $_POST["bairro"];
    $cep = $_POST["cep"];
    $cidade = $_POST["cidade"];
    $estado = $_POST["estado"];
    $telefone = $_POST["telefone"];

    // Consulta SQL para inserir novo cliente usando prepared statement
    $sql = "INSERT INTO clientes (nome_cliente, rua, numero, bairro, cep, cidade, estado, telefone) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssisssss", $nome_cliente, $rua, $numero, $bairro, $cep, $cidade, $estado, $telefone);

    if ($stmt->execute()) {
        $msg = "Novo cliente cadastrado com sucesso!";
        // Limpar campos após o sucesso
        $nome_cliente = $rua = $numero = $bairro = $cep = $cidade = $estado = $telefone = "";
    } else {
        $msg = "Erro ao cadastrar novo cliente: " . $stmt->error;
    }

    // Fechar o statement
    $stmt->close();
}

// Fechar a conexão com o banco de dados
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Sistema JC - Novo Cliente</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #001f3f; 
            color: #fff;
        }
        .header-container {
            display: flex;
            align-items: center;
            padding: 10px;
            background-color: #028ac4; 
            border-bottom: 1px solid #fff; 
            margin-bottom: 20px;
        }
        .header-container img {
            max-height: 50px; 
        }
        .content-container {
            max-width: 800px;
            margin: auto;
            text-align: center; 
        }
        .form-container {
            margin-top: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: 90px;
            margin-bottom: 5px;
        }
        .form-group .form-control {
            width: 100%;
        }
        .form-group.inline {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            margin-bottom: 10px;
        }
        .form-group.inline .form-control {
            flex: 0 0 calc(40% - 5px);
            margin-right: 10px;
        }
        .form-group.inline .form-control:last-child {
            margin-right: 0;
        }
        .btn-block {
            width: 100%; 
        }
    </style>
</head>
<body>

<div class="header-container">
    <img src="img/Asset-11.png" alt="Logo da JC Instalações Elétricas">
    <div class="company-name">JC Instalações Elétricas</div>
</div>

<div class="container content-container">
    <h2 class="text-center mb-4">Novo Cliente</h2>

    <div class="form-container">
        <?php if ($msg): ?>
            <div class="alert alert-<?php echo $msg ? 'success' : 'danger'; ?>" role="alert">
                <?php echo $msg; ?>
            </div>
        <?php endif; ?>

        <form action="novoCliente.php" method="post">
            <div class="form-group">
                <label for="nome_cliente">Nome do Cliente:</label>
                <input type="text" class="form-control" id="nome_cliente" name="nome_cliente" value="<?php echo htmlspecialchars($nome_cliente); ?>" required>
            </div>
            <div class="form-group inline">
                <label for="rua">Rua: </label>
                <input type="text" class="form-control" id="rua" name="rua" value="<?php echo htmlspecialchars($rua); ?>" required>
                <label for="numero">Nº:</label>
                <input type="text" class="form-control" id="numero" name="numero" value="<?php echo htmlspecialchars($numero); ?>" required>
            </div>
            <div class="form-group inline">
                <label for="bairro">Bairro:</label>
                <input type="text" class="form-control" id="bairro" name="bairro" value="<?php echo htmlspecialchars($bairro); ?>" required>
                <label for="cep">CEP:</label>
                <input type="text" class="form-control" id="cep" name="cep" value="<?php echo htmlspecialchars($cep); ?>" required>
            </div>
            <div class="form-group inline">
                <label for="cidade">Cidade:</label>
                <input type="text" class="form-control" id="cidade" name="cidade" value="<?php echo htmlspecialchars($cidade); ?>" required>
                <label for="estado">Estado:</label>
                <input type="text" class="form-control" id="estado" name="estado" value="<?php echo htmlspecialchars($estado); ?>" required>
            </div>
            <div class="form-group">
                <label for="telefone">Telefone:</label>
                <input type="text" class="form-control" id="telefone" name="telefone" value="<?php echo htmlspecialchars($telefone); ?>" required>
            </div>
    
            <button type="submit" class="btn btn-primary btn-block">Cadastrar Cliente</button>
            <a href="cadastro.php" class="btn btn-secondary btn-block">Retornar</a>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
