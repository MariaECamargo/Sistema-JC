<?php
// Conectar ao banco de dados 
$servername = "localhost";
$username = "root";
$password = "";
$database = "sistema_jc";

$conn = new mysqli($servername, $username, $password, $database);

// Verificar a conexão
if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}

// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capturar dados do formulário
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Usar instrução preparada para evitar injeção de SQL
    $sql = "SELECT * FROM usuarios WHERE username=? AND password=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Usuário autenticado com sucesso
        session_start();
        $_SESSION['authenticated'] = true;
        echo "Login bem-sucedido!";
        header('Location: principal.php'); 
        exit;
    } else {
        // Falha na autenticação
        echo "Login falhou. Usuário ou senha incorretos.";
    }

    // Fechar a instrução preparada
    $stmt->close();
}

// Fechar a conexão com o banco de dados
$conn->close();
?>
