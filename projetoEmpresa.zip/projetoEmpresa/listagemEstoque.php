<?php
session_start();

// Verificar se o usuário está autenticado
if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    header('Location: login.php');
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$database = "sistema_jc";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}

// Consulta SQL para obter todos os itens do estoque
$sql = "SELECT * FROM estoque";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Sistema JC - Listagem de Estoque</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #001f3f;
            color: #fff;
            
        }
        .header-container {
            display: flex;
            align-items: center;
            padding: 10px;
            background-color: #028ac4;
            border-bottom: 1px solid #fff; 
            margin-bottom: 20px;
        }
        .header-container img {
            max-height: 50px;
        }
        .table-container {
            max-width: 800px;
            margin: auto;
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="header-container">
    <img src="img/Asset-11.png" alt="Logo da JC Instalações Elétricas">
    <div class="company-name">JC Instalações Elétricas</div>
</div>

<div class="container table-container">
    <h2 class="text-center mb-4">Listagem de Estoque</h2>

    <?php
    if ($result->num_rows > 0) {
        echo '<table class="table table-bordered table-striped">';
        echo '<thead>';
        echo '<tr style="color: #fff;">';
        echo '<th>ID</th>';
        echo '<th>Nome do Item</th>';
        echo '<th>Descrição</th>';
        echo '<th>Quantidade</th>';
        echo '<th>Valor do Item</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';

        // Saída de dados 
        while ($row = $result->fetch_assoc()) {
            echo '<tr style="color: #fff;">';
            echo '<td>' . $row['id'] . '</td>';
            echo '<td>' . $row['nome_item'] . '</td>';
            echo '<td>' . $row['descricao'] . '</td>';
            echo '<td>' . $row['quantidade'] . '</td>';
            echo '<td>R$ ' . number_format($row['valor_item'], 2, ',', '.') . '</td>';
            echo '</tr>';
        }

        echo '</tbody>';
        echo '</table>';
    } else {
        echo 'Nenhum item encontrado no estoque.';
    }
    $conn->close();
    ?>
    <a href="estoque.php" class="btn btn-secondary btn-block menu-btn">Retornar</a>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
