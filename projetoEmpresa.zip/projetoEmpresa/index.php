<?php
session_start();

// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Conectar ao banco de dados
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "sistema_jc";

    $conn = new mysqli($servername, $username, $password, $database);

    // Verificar a conexão
    if ($conn->connect_error) {
        die("Erro na conexão com o banco de dados: " . $conn->connect_error);
    }

    // Capturar dados do formulário
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Usar instrução preparada para evitar injeção de SQL
    $sql = "SELECT * FROM usuarios WHERE username=? AND password=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Usuário autenticado com sucesso
        $_SESSION['authenticated'] = true;
        header('Location: principal.php'); // Redirecionar para a tela principal após o login
        exit;
    } else {
        // Falha na autenticação
        $login_error = "Login falhou. Usuário ou senha incorretos.";
    }

    // Fechar a instrução preparada
    $stmt->close();

    // Fechar a conexão com o banco de dados
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Sistema JC - Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #001f3f; 
            color: #fff;
        }
        .login-container {
            max-width: 400px;
            margin: auto;
            margin-top: 100px;
        }
        .logo-container {
            text-align: center;
        }
        .logo-container img {
            max-width: 100%;
            height: auto;
        }
        .company-name {
            margin-top: 10px;
            font-size: 18px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="container login-container">
    <div class="logo-container">
        <img src="img/Asset-11.png" alt="Logo da JC Instalações Elétricas" height="70px" width="110px">
        <div class="company-name">JC Instalações Elétricas</div>
    </div>
    <h2 class="text-center mb-4"></h2>
    <?php if (isset($login_error)) { ?>
        <div class="alert alert-danger" role="alert">
            <?php echo $login_error; ?>
        </div>
    <?php } ?>
    <form action="index.php" method="post">
        <div class="form-group">
            <label for="username">Usuário:</label>
            <input type="text" class="form-control" id="username" name="username" required>
        </div>
        <div class="form-group">
            <label for="password">Senha:</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <button type="submit" class="btn btn-primary btn-block">Entrar</button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
