<?php
session_start();

// Verificar se o usuário está autenticado
if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    // Redirecionar para a tela de login se não estiver autenticado
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Sistema JC - Principal</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #001f3f;
            color: #fff;
        }
        .header-container {
            display: flex;
            align-items: center;
            padding: 10px;
            background-color: #028ac4; 
            border-bottom: 1px solid #fff; 
            margin-bottom: 20px;
        }
        .header-container img {
            max-height: 50px; 
        }
        .menu-container {
            max-width: 600px;
            margin: auto;
            margin-top: 20px;
        }
        .menu-btn {
            margin-bottom: 10px;
        }
        .logout-btn {
            color: #fff;
            text-decoration: none;
            font-weight: bold;
            margin-left: auto;
        }
        .logout-btn:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="header-container">
    <img src="img/Asset-11.png" alt="Logo da JC Instalações Elétricas">
    <div class="company-name"><strong>JC Instalações Elétricas</strong></div>
    <a href="index.php" class="btn btn-danger logout-btn">Sair</a>
</div>

<div class="container menu-container">
    <h2 class="text-center mb-4">Menu Principal</h2>
    
    <a href="estoque.php" class="btn btn-primary btn-block menu-btn">Estoque</a>
    <a href="cadastroNotaFiscal.php" class="btn btn-primary btn-block menu-btn">Cadastro de Nota Fiscal</a>
    <a href="https://www.gov.br/empresas-e-negocios/pt-br/empreendedor/servicos-para-mei/nota-fiscal/nota-fiscal-de-servico-eletronica-nfs-e" class="btn btn-primary btn-block menu-btn">Emissão de Nota Fiscal</a>
    <a href="cadastro.php" class="btn btn-primary btn-block menu-btn">Cadastro de Clientes</a>
    <a href="orcamento.php" class="btn btn-primary btn-block menu-btn">Orçamento</a>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
